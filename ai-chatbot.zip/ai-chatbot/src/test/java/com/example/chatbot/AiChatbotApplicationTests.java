package com.example.chatbot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AiChatbotApplicationTests {

	@Test
	void contextLoads() {
	}

}
